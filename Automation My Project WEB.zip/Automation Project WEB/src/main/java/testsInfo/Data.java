package testsInfo;

public class Data {

    //------------REGISTRATION FORM DATA-----------------//
    public static final String regexEmailForRegistration = "\\test\\d{10}\\@neogames\\.com";
    public static final String regexLoginAndPasswordForRegistration = "\\Test\\d{10}\\@";
    public static final String FIRST_NAME = "John";
    public static final String LAST_NAME = "Smith";
    public static final String ADDRESS = "42 Constitution Drive";
    public static final String CITY = "San Diego CA";
    public static final String POSTCODE = "92154";
    public static final String PHONE_NUMBER = "1234567";
    public static final String ADDRESS_GERMANY = "ber";


    //------------INNER PAGES DATA-----------------//
    public static final String ABOUT_US_TITLE = "ABOUT US";
    public static final String TERMS_TITLE = "TERMS";
    public static final String PRIVACY_TITLE = "PRIVACY POLICY";
    public static final String RESPONSIBLE_GAMING_TITLE = "PLAY RESPONSIBLY";
    public static final String DEPOSIT_TITLE= "DEPOSITS";
    public static final String CASHOUT_TITLE= "CASHING OUT";
    public static final String HELP_TITLE = "HELP";
    public static final String UNDERAGE_TITLE = "PLAY RESPONSIBLY";
    public static final String ABOUT_US_TEXT = "MrRex";
    public static final String TERMS_TEXT = "ProgressPlay";
    public static final String PRIVACY_TEXT = "privacy";
    public static final String RESPONSIBLE_GAMING_TEXT = "responsible";
    public static final String DEPOSIT_TEXT = "Deposit";
    public static final String CASHOUT_TEXT = "withdraw";
    public static final String PRIVACY_POPUP_TITLE = "PRIVACY POLICY";
    public static final String GAME_TO_SEARCH_BOOK_OF_DEAD = "Book of dead";
}
